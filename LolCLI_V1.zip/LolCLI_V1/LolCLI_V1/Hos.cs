﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LolCLI_V1
{
    internal class Hos
    {
        public string name {  get;private set; }
        public string title {  get;private set; }
        public string category {  get;private set; }
        public List<string> tag { get;private set; }
        public string blurb { get;private set; }
        public double hp {  get;private set; }
        public double hpperlevel { get;private set; }
        public int movespeed {  get;private set; }
        public double armor { get;private set; }
        public int attackrange { get;private set; }
        public double hrregen { get;private set; }
        public double attackdamage { get;private set; }
        public double attackdamageperlevel { get;private set; }
        public double attackspeedperlevel { get;private set; }

        public Hos(string csvline)
        {
           string[] values=csvline.Split(';');
            name = values[0];
            title= values[1];
            category = values[2];
            tag = values[3].Split(',').ToList();
            blurb = values[4];
            hp=double.Parse(values[5]);
            hpperlevel=double.Parse (values[6]);
            movespeed=int.Parse(values[7]);
            armor=double.Parse(values[8]);
            attackrange=int.Parse(values[9]);
            hrregen=double.Parse(values[10]);
            attackdamage=double.Parse(values[11]);
            attackdamageperlevel=double.Parse(values[12]);
            attackspeedperlevel=double.Parse(values[13]);


        }
    }
}
