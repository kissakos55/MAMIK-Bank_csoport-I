﻿namespace LolCLI_V1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Hos> hosok=new List<Hos>();
            string[] sorok = File.ReadAllLines("champions2017.csv");
            foreach (string sor in sorok.Skip(1) ) 
            { 
                hosok.Add(new Hos(sor));
            }
            Console.WriteLine($"2.feladat:Az állományban {hosok.Count} hős található");
        }
    }
}
