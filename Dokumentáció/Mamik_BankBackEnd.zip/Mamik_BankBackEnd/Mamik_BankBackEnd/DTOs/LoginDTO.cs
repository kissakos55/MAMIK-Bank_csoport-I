﻿namespace Mamik_BankBackEnd.DTOs
{
    public class LoginDTO
    {
        public string LoginName { get; set; }

        public string TmpHash { get; set; }
    }
}
