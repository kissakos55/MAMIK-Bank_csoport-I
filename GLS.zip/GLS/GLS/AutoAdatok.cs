﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GLS
{
    public class AutoAdatok
    {
        public string datum {  get;private set; }
        public string sofor { get;private set; }
        public int km { get;private set; }
        public int csomagszam { get;private set; }
        public double fogyasztas { get;private set; }

        public AutoAdatok(string datum, string sofor, int km, int csomagszam, double fogyasztas)
        {
            this.datum = datum;
            this.sofor = sofor;
            this.km = km;
            this.csomagszam = csomagszam;
            this.fogyasztas = fogyasztas;
        }
        public AutoAdatok(string sor) 
        {
            string[]darabok=sor.Split(';');
            this.datum = darabok[0];
            this.sofor=darabok[1];
            this.km=int.Parse(darabok[2]);
            this.csomagszam=int.Parse(darabok[3]);
            this.fogyasztas=double.Parse(darabok[4]);
        }

       

    }
}
