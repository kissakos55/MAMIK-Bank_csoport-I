﻿namespace GLS
{
    internal class Program
    {
        static void Main(string[] args)
        {
           List<AutoAdatok>autok= new List<AutoAdatok>();
          File.ReadAllLines("GLS.txt");
            foreach (var sor in File.ReadAllLines("GLS.txt"))
            {
               autok.Add(new AutoAdatok(sor));
               
            }
            //2.
            Console.WriteLine("Ennyi nap van: "+autok.Count);
            //3.
            Console.WriteLine($"Különböző sofőrök száma:{autok.DistinctBy(f=>f.sofor).Count()}");
            //4.
            Console.WriteLine($"Összes megtett kilóméter:{autok.Sum(f=>f.km)}km");
            //5.
            double osszesliter=autok.Sum(f=>f.fogyasztas);
            int osszeskilometer = autok.Sum(f => f.km);
            Console.WriteLine($"Átlagos fogyasztás:{atlagfogyasztas(osszesliter,osszeskilometer)}");
            //6.
            var ki=autok.GroupBy(f => f.sofor)
                .Select(x => new {Nev= x.Key, db = x.Count() })
                .MaxBy(y => y.db);
            Console.WriteLine($"A legtöbbet vezető sofőr:{ki.Nev}napok száma:{ki.db}");

        }
        public static double atlagfogyasztas(double fogyasztas, int km)
        {
            return fogyasztas / (km / 100.0);


        }
    }
}
